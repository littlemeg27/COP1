﻿using System;
using Tester;

namespace FSPG1
{
    class Program
    {
        static void Main(string[] args)
        {
            Test.Run(3);
            Console.ReadKey();
        }
    }
}
